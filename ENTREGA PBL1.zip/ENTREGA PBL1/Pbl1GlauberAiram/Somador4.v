module Somador4(input[3:0] A,B, input Ci, output[3:0] S, output Co);
	
	//Wires to connect carry in on carry out
	wire c1,c2,c3;
	
	//First bit(column)
	Full(A[0], B[0], Ci,c1,S[0]);
	//Second bit(column)
	Full(A[1],B[1],c1,c2,S[1]);
	//Third bit(column)
	Full(A[2],B[2],c2,c3,S[2]);
	//Fourth bit(column)
	Full(A[3],B[3],c3, Co, S[3]);
endmodule