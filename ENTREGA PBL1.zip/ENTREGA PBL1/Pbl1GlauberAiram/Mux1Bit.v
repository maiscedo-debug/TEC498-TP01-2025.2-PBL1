// =================================================================
// MÓDULO 4: Mux de 1 bit
// =================================================================
// CORRIGIDO: O nome do módulo foi padronizado para Mux1Bit
module Mux1Bit (
    input sel,
    input X,
    input Y,
    output S
);
    wire nsel, t1, t2;

    not(nsel, sel);
    and(t1, nsel, X);
    and(t2, sel, Y);
    or(S, t1, t2);

endmodule

