module Half(input A,B, output Co,S);
	//Sum
	Xor1 (S, A,B);
	//Carry out
	And1 (Co, A,B);
endmodule
