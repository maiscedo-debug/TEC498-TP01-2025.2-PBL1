// =================================================================
// MÓDULO 5: Mux de 4 bits
// =================================================================
module Mux4Bit(
    input sel,
    input  [3:0] X,
    input  [3:0] Y,
    output [3:0] S
);
    
    Mux1Bit mux0 (.sel(sel), .X(X[0]), .Y(Y[0]), .S(S[0]));
    Mux1Bit mux1 (.sel(sel), .X(X[1]), .Y(Y[1]), .S(S[1]));
    Mux1Bit mux2 (.sel(sel), .X(X[2]), .Y(Y[2]), .S(S[2]));
    Mux1Bit mux3 (.sel(sel), .X(X[3]), .Y(Y[3]), .S(S[3]));
    
endmodule
