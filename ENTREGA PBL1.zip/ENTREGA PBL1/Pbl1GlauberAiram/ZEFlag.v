module ZEFlag(input [3:0] R, output Z);
    wire t1, t2, t3;
    or  (t1, R[0], R[1]);
    or  (t2, R[2], R[3]);
    or  (t3, t1, t2);
    not (Z, t3);
endmodule