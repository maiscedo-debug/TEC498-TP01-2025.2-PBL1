module Or1(output Y, input A, B);
    or(Y, A, B);
endmodule