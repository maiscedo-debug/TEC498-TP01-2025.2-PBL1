// =================================================================
// MÓDULO 3: Subtrator de 4 bits
// =================================================================
module Subtractor4(
    input [3:0] A,
    input [3:0] B,
    input Bi,
    output [3:0] Diff,
    output Bo
);
    wire b1, b2, b3;

    FullSub fs0 (.A(A[0]), .B(B[0]), .Bi(Bi), .S(Diff[0]), .Bo(b1));
    FullSub fs1 (.A(A[1]), .B(B[1]), .Bi(b1), .S(Diff[1]), .Bo(b2));
    FullSub fs2 (.A(A[2]), .B(B[2]), .Bi(b2), .S(Diff[2]), .Bo(b3));
    FullSub fs3 (.A(A[3]), .B(B[3]), .Bi(b3), .S(Diff[3]), .Bo(Bo));

endmodule


