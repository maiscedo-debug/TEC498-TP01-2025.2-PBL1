// =================================================================
// MÓDULO 6: Divisor de 4 bits (VERSÃO CORRIGIDA)
// =================================================================
module Divisor4(
    input [3:0] A,
    input [3:0] B,
    output [3:0] Q,
    output [3:0] R
);

    wire bout0, bout1, bout2, bout3;
    wire [3:0] subout0, subout1, subout2, subout3;
    wire [3:0] prem0, prem1, prem2;

    // --- Passo 1 ---
    Subtractor4 sub0 (.A({3'b000, A[3]}), .B(B), .Bi(1'b0), .Diff(subout0), .Bo(bout0));
    // CORRIGIDO: Entradas X e Y do MUX foram invertidas
    Mux4Bit mux0 (.sel(bout0), .X(subout0), .Y({3'b000, A[3]}), .S(prem0));
    not(Q[3], bout0);

    // --- Passo 2 ---
    Subtractor4 sub1 (.A({prem0[2:0], A[2]}), .B(B), .Bi(1'b0), .Diff(subout1), .Bo(bout1));
    // CORRIGIDO: Entradas X e Y do MUX foram invertidas
    Mux4Bit mux1 (.sel(bout1), .X(subout1), .Y({prem0[2:0], A[2]}), .S(prem1));
    not(Q[2], bout1);

    // --- Passo 3 ---
    Subtractor4 sub2 (.A({prem1[2:0], A[1]}), .B(B), .Bi(1'b0), .Diff(subout2), .Bo(bout2));
    // CORRIGIDO: Entradas X e Y do MUX foram invertidas
    Mux4Bit mux2 (.sel(bout2), .X(subout2), .Y({prem1[2:0], A[1]}), .S(prem2));
    not(Q[1], bout2);

    // --- Passo 4 ---
    Subtractor4 sub3 (.A({prem2[2:0], A[0]}), .B(B), .Bi(1'b0), .Diff(subout3), .Bo(bout3));
    // CORRIGIDO: Entradas X e Y do MUX foram invertidas
    Mux4Bit mux3 (.sel(bout3), .X(subout3), .Y({prem2[2:0], A[0]}), .S(R));
    not(Q[0], bout3);
    
endmodule