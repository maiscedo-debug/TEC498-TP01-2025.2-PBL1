module e4( A, Y, B);
	input [3:0]Y, B;
	output [3:0]A;
	
	And1 a0(A[0], B[0], Y[0]);
    And1 a1(A[1], B[1], Y[1]);
    And1 a2(A[2], B[2], Y[2]);
    And1 a3(A[3], B[3], Y[3]);
endmodule
