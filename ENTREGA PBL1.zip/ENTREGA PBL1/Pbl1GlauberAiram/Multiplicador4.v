module Multiplicador4(input [3:0] A,B, output [3:0] P, output overflow);

    //Products
    wire b0a1, b0a2, b0a3;
    wire b1a0, b1a1, b1a2, b1a3;
    wire b2a0, b2a1, b2a2, b2a3;
    wire b3a0, b3a1, b3a2, b3a3;

    And1(b0a1, A[1], B[0]);
    And1(b0a2, A[2], B[0]);
    And1(b0a3, A[3], B[0]);
    And1(b1a0, A[0], B[1]);
    And1(b1a1, A[1], B[1]);
    And1(b1a2, A[2], B[1]);
    And1(b1a3, A[3], B[1]);
    And1(b2a0, A[0], B[2]);
    And1(b2a1, A[1], B[2]);
    And1(b2a2, A[2], B[2]);
    And1(b2a3, A[3], B[2]);
    And1(b3a0, A[0], B[3]);
    And1(b3a1, A[1], B[3]);
    And1(b3a2, A[2], B[3]);
    And1(b3a3, A[3], B[3]);

    //Carry in's
    wire c1, c2, c3, c4, c5, c6, c7;

    //Sums
    wire s1, s2, s3, s4;

    //Column(0)
    And1(P[0], A[0], B[0]);

    //Column(1)
    Half(b0a1, b1a0, c1, P[1]);

    //Column(2)
    Full(b0a2, b1a1, c1, c2, s1);
    Half(s1, b2a0, c3, P[2]);

    //Column(3)
    Full(c2, b0a3, c3, c4, s2);
    Half(b1a2, s2, c5, s3);
    Half(b2a1, s3, c6, s4);
    Half(s4, b3a0, c7, P[3]);

    // ------------------------------
    // Overflow = c7 + todos os produtos ignorados
    // ------------------------------
    wire t1, t2, t3, t4, t5, t6;

    Or1(t1, c7,  b1a3);
    Or1(t2, t1,  b2a2);
    Or1(t3, t2,  b2a3);
    Or1(t4, t3,  b3a1);
    Or1(t5, t4,  b3a2);
    Or1(t6, t5,  b3a3);
    // saída final
    Or1(overflow, t6, c4);  // c4 também não foi usado no resultado truncado

endmodule
