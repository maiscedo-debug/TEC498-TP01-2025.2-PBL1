module Not1(output Y, input A, input B);
    not(Y, A);
endmodule
