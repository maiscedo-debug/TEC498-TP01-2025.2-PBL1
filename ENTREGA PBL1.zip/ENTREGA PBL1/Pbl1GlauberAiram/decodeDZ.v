module decodeDZ(
    output [6:0] S,  // segmentos do display da dezena
    input        ov  // sinal que indica >= 10 (vindo do Decodificador das unidades)
);

    wire f;

    not(f, ov);

    // segmentos que devem acender quando ov=1 → "1" no display
    not(S[0], f);
    not(S[3], f);
    not(S[4], f);
    not(S[5], f);

    // segmentos que ficam sempre em 0
    and(S[1], f, 1'b0);
    and(S[2], f, 1'b0);

    // segmento que fica sempre em 1
    or(S[6], ov, 1'b1);
endmodule