module Xor1(output Y, input A, B);
    xor(Y, A, B);
endmodule
