module main(
    // --- Entradas ---
    input  [3:0] A,        // Operando A
    input  [3:0] B,        // Operando B
    input  [2:0] OP_SEL,   // Seletor de Operação
    input CiBi,

    // --- Saídas ---
    output [3:0] RESULT,   // Resultado da operação (4 bits)
    output       Z_FLAG,   // Flag de Zero (Resultado é 0?)
    output       C_FLAG,   // Flag de Carry/Borrow
    output       OV_FLAG,  // Flag de Overflow (por exemplo, multiplicação > 15)
    output       ERR_FLAG, // Flag de Erro (ex: divisão por zero)

    // --- Displays (novas saídas) ---
    output [6:0] DISPLAY_UNID, // display das unidades (7 segmentos)
    output [6:0] DISPLAY_DEZ   // display da dezena (7 segmentos) - mostra '1' quando >=10
);

    // -- (todo o resto do seu código permanece igual até aqui) --

    // --- FIOS INTERNOS PARA CADA RESULTADO DE OPERAÇÃO ---
    wire [3:0] res_soma;
    wire       cout_soma;
   
    wire [3:0] res_sub;
    wire       bout_sub;

    wire [7:0] res_mult_full; // se seu Multiplicador já entrega 4 bits, ajuste aqui; mantenho 8 caso seja completo
    wire [3:0] res_mult;      // os 4 LSBs usados em RESULT
    wire       overflow;      // overflow interno do multiplicador

    wire [3:0] res_div_q; // Quociente
    wire [3:0] res_div_r; // Resto

    wire [3:0] res_and;
    wire [3:0] res_or;
    wire [3:0] res_xor;

    // =============================================================
    // PASSO 1: INSTANCIAR TODAS AS UNIDADES FUNCIONAIS
    // =============================================================

    // 1. Somador
    Somador4 u_soma (.A(A), .B(B), .Ci(CiBi), .S(res_soma), .Co(cout_soma));
   
    // 2. Subtrator
    Subtractor4 u_sub (.A(A), .B(B), .Bi(CiBi), .Diff(res_sub), .Bo(bout_sub));

    // 3. Multiplicador
    // Se seu multiplicador entrega só 4 bits (res_mult) e um overflow, use dessa forma:
    Multiplicador4 u_mult (.A(A), .B(B), .P(res_mult), .overflow(overflow));
    // Se tiver versão que entrega 8 bits, adapte os nomes conforme seu módulo.

    // 4. Divisor
    Divisor4 u_div (.A(A), .B(B), .Q(res_div_q), .R(res_div_r));

    // 5. Lógica AND (4 bits)
    e4 u_and(res_and, A, B);
   
    // 6. Lógica OR (4 bits)
    ou4 u_or(res_or, A, B);
   
    // 7. Lógica XOR (4 bits)
    ouex4 u_xor(res_xor, A, B);

    // =============================================================
    // PASSO 2: USAR O MUX PRINCIPAL PARA SELECIONAR O RESULTADO
    // =============================================================

    // MUXs por bit (como você já tinha). O RESULT final é um fio de 4 bits.
    // (uso as mesmas instâncias que você já tinha — aqui só reafirmei que RESULT sai do mux)
    mux8PARA1 mux_r0(
        .I0(res_soma[0]), .I1(res_sub[0]), .I2(res_mult[0]), .I3(res_div_q[0]),
        .I4(res_and[0]), .I5(res_or[0]), .I6(res_xor[0]),
        .SEL(OP_SEL), .Y(RESULT[0])
    );
    mux8PARA1 mux_r1(
        .I0(res_soma[1]), .I1(res_sub[1]), .I2(res_mult[1]), .I3(res_div_q[1]),
        .I4(res_and[1]), .I5(res_or[1]), .I6(res_xor[1]),
        .SEL(OP_SEL), .Y(RESULT[1])
    );
    mux8PARA1 mux_r2(
        .I0(res_soma[2]), .I1(res_sub[2]), .I2(res_mult[2]), .I3(res_div_q[2]),
        .I4(res_and[2]), .I5(res_or[2]), .I6(res_xor[2]),
        .SEL(OP_SEL), .Y(RESULT[2])
    );
    mux8PARA1 mux_r3(
        .I0(res_soma[3]), .I1(res_sub[3]), .I2(res_mult[3]), .I3(res_div_q[3]),
        .I4(res_and[3]), .I5(res_or[3]), .I6(res_xor[3]),
        .SEL(OP_SEL), .Y(RESULT[3])
    );

    // ----------------------------
    // FLAGS (igual ao seu design)
    // ----------------------------
    ZEFlag zf_result(.R(RESULT), .Z(Z_FLAG));
    wire B_is_zero;
    ZEFlag zf_B(.R(B), .Z(B_is_zero));

    mux8PARA1 mux_err(
        .I0(1'b0), .I1(1'b0), .I2(1'b0), .I3(B_is_zero),
        .I4(1'b0), .I5(1'b0), .I6(1'b0), .I7(1'b0),
        .SEL(OP_SEL), .Y(ERR_FLAG) );

    mux8PARA1 mux_carry(
        .I0(cout_soma), .I1(bout_sub), .I2(1'b0), .I3(1'b0),
        .I4(1'b0), .I5(1'b0), .I6(1'b0), .I7(1'b0),
        .SEL(OP_SEL), .Y(C_FLAG) );

    mux8PARA1 mux_ov(
        .I0(1'b0), .I1(1'b0), .I2(overflow), .I3(1'b0),
        .I4(1'b0), .I5(1'b0), .I6(1'b0), .I7(1'b0),
        .SEL(OP_SEL), .Y(OV_FLAG) );

    // =============================================================
    // PASSO 3: DECODIFICADORES PARA DISPLAYS (ESTRUTURAL)
    // =============================================================

    // fio que indica se RESULT >= 10 (vindo do Decodificador das unidades)
    wire decunit_ov;

    // Decodificador das unidades: recebe RESULT[3:0], produz 7 seg e Ov (>=10)
    decodeUN u_dec_unit (
        .S(DISPLAY_UNID), // diretamente nas saídas do display de unidades
        .Ov(decunit_ov),  // este fio será usado para a dezena
        .A(RESULT)
    );

    // Decodificador da dezena: mostra '1' apenas quando decunit_ov = 1
    decodeDZ u_dec_dez (
        .S(DISPLAY_DEZ),
        .ov(decunit_ov)
    );

endmodule