module ou4(output [3:0] A, input [3:0] Y, B);
    Or1(A[0], B[0], Y[0]);
    Or1(A[1], B[1], Y[1]);
    Or1(A[2], B[2], Y[2]);
    Or1(A[3], B[3], Y[3]);
endmodule