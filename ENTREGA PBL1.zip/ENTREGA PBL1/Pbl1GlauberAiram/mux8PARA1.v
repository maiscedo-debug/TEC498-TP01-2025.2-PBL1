module mux8PARA1(
    input I0, I1, I2, I3, I4, I5, I6, I7, 
    input [2:0]SEL,        
    output Y           
);
    wire not_S2, not_S1, not_S0;
    wire and0, and1, and2, and3, and4, and5, and6, and7;

    not (not_S2, SEL[2]);
    not (not_S1, SEL[1]);
    not (not_S0, SEL[0]);

    and (and0, not_S2, not_S1, not_S0, I0);
    and (and1, not_S2, not_S1, SEL[0], I1);
    and (and2, not_S2, SEL[1], not_S0, I2);
    and (and3, not_S2, SEL[1], SEL[0], I3);
    and (and4, SEL[2], not_S1, not_S0, I4);
    and (and5, SEL[2], not_S1, SEL[0], I5);
    and (and6, SEL[2], SEL[1], not_S0, I6);
    and (and7, SEL[2], SEL[1], SEL[0], I7);

    or (Y, and0, and1, and2, and3, and4, and5, and6, and7);
endmodule