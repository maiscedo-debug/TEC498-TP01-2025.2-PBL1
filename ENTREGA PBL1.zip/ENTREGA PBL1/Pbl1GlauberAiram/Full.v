module Full(A,B,Ci,Co,S);

	//Entraces and outputs
	input A,B,Ci;
	output S, Co;
	//Wires
	wire AxorB, AandB, CinAxorB;
	
	//Sum
	Xor1(AxorB,A,B);
	Xor1(S,AxorB,Ci);
	
	//Carry out
	And1 (AandB, A, B);
	And1 (CinAxorB, Ci, AxorB);
	Or1 (Co, AandB, CinAxorB);
	
endmodule
