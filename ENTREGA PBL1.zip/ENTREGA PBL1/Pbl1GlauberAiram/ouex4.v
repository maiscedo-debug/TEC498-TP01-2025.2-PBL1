module ouex4(output [3:0] Y, input [3:0] A, B);
    Xor1 x0(Y[0], A[0], B[0]);
    Xor1 x1(Y[1], A[1], B[1]);
    Xor1 x2(Y[2], A[2], B[2]);
    Xor1 x3(Y[3], A[3], B[3]);
endmodule
